import React from 'react';

const ChangePassword = () => {
    return (
        <div>
            this is ChangePassword!!!
        </div>
    );
}

export default ChangePassword;
