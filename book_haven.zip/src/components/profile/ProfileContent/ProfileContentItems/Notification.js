import React from 'react';

const Notification = () => {
    return (
        <div>
            this is notifications!!
        </div>
    );
}

export default Notification;
