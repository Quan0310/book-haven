import React from 'react';

const OrderManage = () => {
    return (
        <div>
            this is OrderManage!!!
        </div>
    );
}

export default OrderManage;
