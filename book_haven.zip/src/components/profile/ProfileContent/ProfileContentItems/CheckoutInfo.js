import React from 'react';

const CheckoutInfo = () => {
    return (
        <div>
            this is CheckoutInfo!!!
        </div>
    );
}

export default CheckoutInfo;
