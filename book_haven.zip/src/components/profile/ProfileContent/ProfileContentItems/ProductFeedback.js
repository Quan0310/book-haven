import React from 'react';

const ProductFeedback = () => {
    return (
        <div>
            this is ProductFeedback!!!
        </div>
    );
}

export default ProductFeedback;
