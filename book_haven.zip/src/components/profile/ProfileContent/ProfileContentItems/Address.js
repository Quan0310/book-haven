import React from 'react';

const Address = () => {
    return (
        <div>
            this is Address!!!
        </div>
    );
}

export default Address;
