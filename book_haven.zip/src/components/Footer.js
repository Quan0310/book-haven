import React from 'react';

const Footer = () => {
    return (
        <div style={{ backgroundColor: 'orange' }} >
            <div style={{ maxWidth: '1200px', margin: '0 auto', width: '100%', height: '100px', backgroundColor: 'yellow' }}>
                this is footer!
            </div>
        </div>
    );
}

export default Footer;
